<marquee direction="up">
<p>
    Tarih Mula Pertandingan: 12/01/2022<br>
    Tarikh Tutup Pertandingan: 15/01/2022<br>
    Pertandingan Telah Tamat<br>
</p>
<p>
    Tarih Mula Pertandingan: 12/01/2022<br>
    Tarikh Tutup Pertandingan: 15/01/2022<br>
    Pertandingan Telah Tamat<br>
</p>
<p>
    Tarih Mula Pertandingan: 12/01/2022<br>
    Tarikh Tutup Pertandingan: 15/01/2022<br>
    Pertandingan Telah Tamat<br>
</p>
</marquee>